package pl.transport;

public interface Interfejs {
    double obliczKoszt(double dystans);
}